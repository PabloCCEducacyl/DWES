<?php include('encabezado.php');?>
    <ul class="lista-index">
        <li><a href="formulario_agregar_alumno.php">Agregar Alumno</a></li>
        <li><a href="listar_alumno.php">Listar Alumnos</a></li>
        <li><a href="formulario_modificar_alumno.php">Modificar Alumno</a></li>
        <li><a href="eliminar_alumno.php">Eliminar Alumno</a></li>
    </ul>
<?php include('footer.php');?>